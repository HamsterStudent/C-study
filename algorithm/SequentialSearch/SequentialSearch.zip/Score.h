#pragma once

typedef struct
{
    int    number;
    double score;
} Score;

